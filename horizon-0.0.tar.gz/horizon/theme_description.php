<?php
$theme_description['name'] = 'Horizon';
$theme_description['author'] = 'Roland Ti - <a href="https://github.com/RolandTi/horizon ">GitHub</a>';
$theme_description['version'] = '0.0';
$theme_description['date'] = '08/04/23';
$theme_description['desc'] = 'Horizon is a responsive theme for ZenphotoCMS.';
?>