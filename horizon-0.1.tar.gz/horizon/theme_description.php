<?php
$theme_description['name'] = 'Horizon';
$theme_description['author'] = 'Roland Ti - <a href="https://github.com/RolandTi/horizon ">GitHub</a>';
$theme_description['version'] = '0.1';
$theme_description['date'] = '09/04/23';
$theme_description['desc'] = 'Horizon is a responsive theme for ZenphotoCMS.';
?>