	<details>
		<summary>Credits</summary>
		<ul class="foot-links">
			<?php printPrivacyPageLink('<li>', '</li>'); ?>
			<li><?php printZenphotoLink(); ?></li>
			<?php printCopyrightNotice('<li>', '</li>'); ?>
		</ul>
	</details>
	<?php zp_apply_filter('theme_body_close'); ?>
	
	<script src="<?php echo $_zp_themeroot; ?>/js/horizon.js?v=1"></script>
